-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 27, 2024 at 03:34 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.1.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `events`
--

-- --------------------------------------------------------

--
-- Table structure for table `buildings`
--

CREATE TABLE `buildings` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `site` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `buildings`
--

INSERT INTO `buildings` (`id`, `name`, `site`, `created_at`, `updated_at`) VALUES
(2, 'New Building Added', 'Left Corner', '2024-01-27 08:59:23', '2024-01-27 08:59:23');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `added_by` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `added_by`, `name`, `created_at`, `updated_at`) VALUES
(1, NULL, 'Test Category updated', '2024-01-27 07:58:10', '2024-01-27 07:58:10'),
(4, NULL, 'New Cat', '2024-01-27 10:17:46', '2024-01-27 10:17:46'),
(5, NULL, 'Updated One', '2024-01-27 12:12:30', '2024-01-27 12:12:30');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id` int(11) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `building_id` int(11) DEFAULT NULL,
  `title` text DEFAULT NULL,
  `start_date` varchar(255) DEFAULT NULL,
  `start_time` varchar(100) DEFAULT NULL,
  `end_date` varchar(255) DEFAULT NULL,
  `end_time` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `image` text DEFAULT NULL,
  `priority` varchar(255) DEFAULT NULL,
  `is_weekly` varchar(255) DEFAULT NULL,
  `bi_weekly` varchar(255) DEFAULT NULL,
  `is_public` varchar(255) NOT NULL,
  `coordinator` varchar(255) DEFAULT NULL,
  `address` text NOT NULL,
  `postcode` varchar(255) NOT NULL,
  `capacity` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `required_booking` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `created_by`, `category_id`, `building_id`, `title`, `start_date`, `start_time`, `end_date`, `end_time`, `description`, `image`, `priority`, `is_weekly`, `bi_weekly`, `is_public`, `coordinator`, `address`, `postcode`, `capacity`, `email`, `required_booking`) VALUES
(9, 2, 1, 2, 'Test', '2024-01-31', '12:59', '2024-01-31', '11:59', 'sdasd', 'eventImages/article_aligned@2x.jpg', 'Low', '1', '0', '0', 'Cordinators', 'Flate No #4 Block A4 Rabia City Gulistan e Jauhar Karachi Sindh Pakistan', '75290', 12, 'sajjad@gmail.com', 1),
(10, 1, 1, 2, 'Test', '2024-01-31', '12:59', '2024-01-31', '11:59', 'sdasd', 'eventImages/motivational_speakers.jpg', 'Low', '1', '0', '0', 'Cordinators', 'Flate No #4 Block A4 Rabia City Gulistan e Jauhar Karachi Sindh Pakistan', '75290', 12, 'sajjad@gmail.com', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `role` varchar(255) DEFAULT 'user',
  `name` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `role`, `name`, `username`, `email`, `password`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'Admin', 'Admin', 'admin@gmail.com', '$2y$10$CHymf3RA005H6KqxNk8Zc.TFKb0gotySdr6oqI9ChTc1FupMz8FFi', '2024-01-27 07:10:04', '2024-01-27 07:10:04'),
(2, 'user', 'Sajjad Ali', 'sajjad', 'sajjad@gmail.com', '$2y$10$CHymf3RA005H6KqxNk8Zc.TFKb0gotySdr6oqI9ChTc1FupMz8FFi', '2024-01-27 07:10:04', '2024-01-27 07:10:04');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `buildings`
--
ALTER TABLE `buildings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `buildings`
--
ALTER TABLE `buildings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
