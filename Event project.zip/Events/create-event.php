<?php
session_start(); // Start the session

// Check if the user is logged in
$isLoggedIn = isset($_SESSION['user']);

include('admin/includes/db.php')

?>

<?php
// Sample array of events
$events = [
    ['name' => 'Event 1', 'date' => '2024-12-31 12:00:00'],
    ['name' => 'Event 2', 'date' => '2025-01-15 18:30:00'],
    // Add more events as needed
];


?>


<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Admin</title>

    <link rel="stylesheet" href="admin/assets/css/styles.min.css" />
</head>

<body>

    <div class="overlay"></div>
    <!-- navbar start -->
    <?php
    include('navbar.php')
    ?>

    <div class="container-fluid">
        <div class="container">
            <div class="card">
                <div class="card-body mb-5">
                    <h5 class="card-title fw-semibold mb-4">Create New Event</h5>
                    <div class=" mb-5">
                        <div class="">
                            <form method="POST" enctype="multipart/form-data" action="database-process.php">
                                <div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label">Event Title</label>
                                    <input type="hidden" name="form_type" value="create-event">

                                    <input type="text" name="title" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" required>
                                </div>


                                <div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label">Start Date</label>

                                    <input type="date" name="start_date" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" required>
                                </div>


                                <div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label">Start Time</label>

                                    <input type="time" name="start_time" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" required>
                                </div>


                                <div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label">End Date</label>

                                    <input type="date" name="end_date" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" required>
                                </div>


                                <div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label">End Time</label>

                                    <input type="time" name="end_time" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" required>
                                </div>





                                <div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label">Description</label>
                                    <textarea name="description" class="form-control" id="" cols="30" rows="4"></textarea>
                                </div>


                                <div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label">Image</label>
                                    <input type="file" name="image" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" required>
                                </div>

                                <div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label">Room</label>

                                    <select name="building_id" class="form-control" id="">

                                        <?php
                                        $sql = "SELECT * FROM buildings";
                                        $result = $conn->query($sql);


                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {

                                        ?>
                                                <option value="<?php echo $row['id'] ?>"><?php echo $row['name'] ?></option>
                                        <?php
                                            }
                                        }
                                        ?>


                                    </select>
                                </div>

                                <div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label">Category</label>
                                    <select name="category_id" required class="form-control" id="">
                                        <?php
                                        $sql = "SELECT * FROM categories";
                                        $result = $conn->query($sql);


                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {

                                        ?>
                                                <option value="<?php echo $row['id'] ?>"><?php echo $row['name'] ?></option>
                                        <?php
                                            }
                                        }
                                        ?>

                                    </select>

                                </div>

                                <div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label">Priority</label>
                                    <select required name="priority" class="form-control" id="">
                                        <option value="Low">Low</option>
                                        <option value="High">High</option>
                                        <option value="Medium">Medium</option>
                                    </select>

                                </div>
                                <!-- <div class="mb-3">
                                    <input type="checkbox" name="is_weekly" value="is_weekly" class="" id="exampleInputEmail1" aria-describedby="emailHelp">
                                    <label for="exampleInputEmail1" class="form-label">Is Weekly </label>


                                </div>

                                <div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label"> <input type="checkbox" name="bi_weekly" value="bi_weekly" class="" id="exampleInputEmail1" aria-describedby="emailHelp"> Bi Weeokly</label>
                                </div>


                                <div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label"> <input type="checkbox" name="is_public" value="is_public" class="" id="exampleInputEmail1" aria-describedby="emailHelp"> Is Public</label>
                                </div> -->

                                <div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label">Coordinator</label>

                                    <input type="text" name="coordinator" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" required>
                                </div>

                                <div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label">Address</label>

                                    <input type="text" name="address" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" required>
                                </div>

                                <div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label">Postcode</label>

                                    <input type="text" name="postcode" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" required>
                                </div>


                                <div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label">Capacity</label>

                                    <input type="number" name="capacity" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" required>
                                </div>


                                <div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label">Email</label>

                                    <input type="email" name="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" required>
                                </div>

                                <div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label"> <input type="checkbox" name="required_booking" value="required_booking" class="" id="exampleInputEmail1" aria-describedby="emailHelp" required> Required Booking</label>
                                </div>

                                <button type="submit" class="btn btn-primary" style="width: 20%;">Add Event</button>
                            </form>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>




    <!-- navbar end -->
    <script src=" assets/libs/jquery/dist/jquery.min.js">
    </script>
    <script src="assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>