<!-- Sidebar Start -->

<?php

include('layout.php');
include('includes/db.php')

?>
<!--  Sidebar End -->

<!-- Sidebar Start -->
<?php
include('includes/sidebar.php')
?>
<!--  Sidebar End -->


<div class="body-wrapper">
    <!--  Header Start -->
    <?php
    include('includes/header.php')
    ?>
    <!--  Header End -->
    <div class="container-fluid">
        <div class="container-fluid">
            <div class="card">
                <div class="card-body mb-5">
                    <h5 class="card-title fw-semibold mb-4">Add Category</h5>
                    <div class=" mb-5">

                        <?php

                        if (isset($_GET['id'])) {
                            $categoryId = $_GET['id'];

                            $sql = "SELECT * FROM categories WHERE id=" . $categoryId;
                            $result = $conn->query($sql);

                            if ($result->num_rows > 0) {
                                $row = $result->fetch_assoc();
                            }
                        }

                        ?>
                        <div class="">
                            <form method="POST" action="admin-database-process.php">
                                <div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label">Category Name</label>
                                    <input type="hidden" name="form_type" value="update-category">
                                    <input type="hidden" name="id" value="<?php echo $row['id'] ?>">

                                    <input type="text" name="name" value="<?php echo $row['name'] ?>" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                                </div>
                                <button type="submit" class="btn btn-primary" style="width: 20%;">Update Category </button>
                            </form>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <?php include('includes/sign.php') ?>
    </div>
</div>
</div>

<?php
include('includes/footer.php')
?>