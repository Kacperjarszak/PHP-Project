<div class="py-6 px-6 text-center">
    <p class="mb-0 fs-4">Design and Developed by <a href="#" target="_blank" class="pe-1 text-primary text-decoration-underline">Kacper </a> <a href="/">Jarszak</a>
    </p>
</div>