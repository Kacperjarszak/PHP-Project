<!-- Sidebar Start -->


<?php
include('layout.php');
include('includes/db.php')

?>
<!--  Sidebar End -->

<!-- Sidebar Start -->
<?php
include('includes/sidebar.php')
?>
<!--  Sidebar End -->


<div class="body-wrapper">
    <!--  Header Start -->
    <?php
    include('includes/header.php')
    ?>
    <!--  Header End -->
    <div class="container-fluid">


        <div class="row">
            <div class="col-sm-12 col-xl-12">
                <div class="card ">
                    <div class="card-body pt-3 p-4">
                        <div class="d-flex justify-content-between mb-4">
                            <div>
                                <h5 class="card-title fw-semibold mb-4 ml-5">Categories</h5>

                            </div>

                            <div class=""><a href="create-category.php" class="btn btn-success">Create Category</a></div>
                        </div>

                        <?php if (isset($_GET['error'])) : ?>
                            <div class="alert alert-danger" role="alert">
                                <?php echo htmlspecialchars($_GET['error']); ?>
                            </div>
                        <?php endif; ?>

                        <?php if (isset($_GET['success'])) : ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo htmlspecialchars($_GET['success']); ?>
                            </div>
                        <?php endif; ?>
                        <div class="table-responsive">
                            <table class="table text-nowrap mb-0 align-middle">
                                <thead class="text-dark fs-4">
                                    <tr>
                                        <th class="border-bottom-0">
                                            <h6 class="fw-semibold mb-0">Id</h6>
                                        </th>
                                        <th class="border-bottom-0">
                                            <h6 class="fw-semibold mb-0">Category Name</h6>
                                        </th>

                                        <th class="border-bottom-0 text-end">
                                            <h6 class="fw-semibold mb-0">Action</h6>
                                        </th>

                                    </tr>
                                </thead>
                                <tbody>

                                    <?php
                                    $sql = "SELECT * FROM categories";
                                    $result = $conn->query($sql);


                                    if ($result->num_rows > 0) {
                                        while ($row = $result->fetch_assoc()) {

                                    ?>

                                            <tr>
                                                <td class="border-bottom-0">
                                                    <h6 class="fw-semibold mb-0"><?php echo $row['id'] ?></h6>
                                                </td>
                                                <td class="border-bottom-0">
                                                    <h6 class="fw-semibold mb-1"><?php echo $row['name'] ?></h6>
                                                </td>


                                                <td class="border-bottom-0 text-end">

                                                    <a href="edit-category.php?id=<?php echo $row['id']; ?>"><i class=" ti ti-edit" style="font-size: 20px; color:black"></i></a>


                                                    <a href="delete-category.php?id=<?php echo $row['id']; ?>"><i class="ti ti-trash" style="font-size: 20px; color:black"></i></a>
                                                </td>
                                            </tr>


                                    <?php


                                        }
                                    }


                                    ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php include('includes/sign.php') ?>
    </div>
</div>
</div>

<?php
include('includes/footer.php')
?>