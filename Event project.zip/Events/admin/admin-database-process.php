<?php
include('includes/db.php');

session_start(); // Start the session



include('includes/db.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['form_type']) && $_POST['form_type'] == 'create-category') {
        $categoryName = htmlspecialchars($_POST['name']);
        $sql = "INSERT INTO categories (name) VALUES ('$categoryName')";
        if ($conn->query($sql) === TRUE) {
            header("Location: event-categories.php?success=Category added successfully");
            exit();
        } else {
            $error = "Error: " . $sql . "<br>" . $conn->error;
            header("Location: event-categories.php?error=" . urlencode($error));
            exit();
        }
    }

    if (isset($_POST['form_type']) && $_POST['form_type'] == 'update-category') {
        $categoryId = intval($_POST['id']); // Ensure the ID is an integer
        $categoryName = htmlspecialchars($_POST['name']);

        // Use UPDATE statement to update the category
        $sql = "UPDATE categories SET name='$categoryName' WHERE id=$categoryId";

        if ($conn->query($sql) === TRUE) {
            header("Location: event-categories.php?success=Category updated successfully");
            exit();
        } else {
            $error = "Error: " . $sql . "<br>" . $conn->error;
            header("Location: event-categories.php?error=" . urlencode($error));
            exit();
        }
    }


    if (isset($_POST['form_type']) && $_POST['form_type'] == 'create-building') {
        $categoryName = htmlspecialchars($_POST['name']);
        $categorysite = htmlspecialchars($_POST['site']);
        $sql = "INSERT INTO buildings (name,site) VALUES ('$categoryName','$categorysite')";
        if ($conn->query($sql) === TRUE) {
            header("Location: buildings.php?success=Building added successfully");
            exit();
        } else {
            $error = "Error: " . $sql . "<br>" . $conn->error;
            header("Location: buildings.php?error=" . urlencode($error));
            exit();
        }
    }


    if (isset($_POST['form_type']) && $_POST['form_type'] == 'update-building') {
        $categoryId = intval($_POST['id']); // Ensure the ID is an integer
        $categoryName = htmlspecialchars($_POST['name']);
        $categorySite = htmlspecialchars($_POST['site']);

        // Use UPDATE statement to update the category
        $sql = "UPDATE buildings SET name='$categoryName', site='$categorySite' WHERE id=$categoryId";

        if ($conn->query($sql) === TRUE) {
            header("Location: buildings.php?success=Building updated successfully");
            exit();
        } else {
            $error = "Error: " . $sql . "<br>" . $conn->error;
            header("Location: buildings.php?error=" . urlencode($error));
            exit();
        }
    }


    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['form_type']) && $_POST['form_type'] == 'create-event') {

        $title = mysqli_real_escape_string($conn, $_POST['title']);
        $start_date = $_POST['start_date'];
        $start_time = $_POST['start_time'];
        $end_date = $_POST['end_date'];
        $end_time = $_POST['end_time'];
        $description = mysqli_real_escape_string($conn, $_POST['description']);
        $building_id = $_POST['building_id'];
        $category_id = $_POST['category_id'];
        $priority = $_POST['priority'];
        $is_weekly = isset($_POST['is_weekly']) ? 1 : 0;
        $bi_weekly = isset($_POST['bi_weekly']) ? 1 : 0;
        $is_public = isset($_POST['is_public']) ? 1 : 0;
        $coordinator = mysqli_real_escape_string($conn, $_POST['coordinator']);
        $address = mysqli_real_escape_string($conn, $_POST['address']);
        $postcode = mysqli_real_escape_string($conn, $_POST['postcode']);
        $capacity = $_POST['capacity'];
        $email = $_POST['email'];
        $required_booking = isset($_POST['required_booking']) ? 1 : 0;

        $user_id = $_SESSION['user']['id'];



        $targetDirectory = "eventImages/";
        $image = $_FILES['image']['name'];
        $targetPath = $targetDirectory . basename($image);
        move_uploaded_file($_FILES["image"]["tmp_name"], $targetPath);

        // Insert data into the database
        $sql = "INSERT INTO events (created_by,title, start_date, start_time, end_date, end_time, description, image, building_id, category_id, priority, is_weekly, bi_weekly, is_public, coordinator, address, postcode, capacity, email, required_booking) 
            VALUES ('$user_id','$title', '$start_date', '$start_time', '$end_date', '$end_time', '$description', '$targetPath', '$building_id', '$category_id', '$priority', '$is_weekly', '$bi_weekly', '$is_public', '$coordinator', '$address', '$postcode', '$capacity', '$email', '$required_booking')";

        if ($conn->query($sql) === TRUE) {
            header("Location: events.php?success=Event added successfully");
            exit();
        } else {
            $error = "Error: " . $sql . "<br>" . $conn->error;
            header("Location: event.php?error=" . urlencode($error));
            exit();
        }
    } else {

        header("Location: events.php");
        exit();
    }





    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['type']) && $_POST['type'] == 'update-event') {



        $event_id = $_POST['event_id'];
        $title = mysqli_real_escape_string($conn, $_POST['title']);
        $start_date = $_POST['start_date'];
        $start_time = $_POST['start_time'];
        $end_date = $_POST['end_date'];
        $end_time = $_POST['end_time'];
        $description = mysqli_real_escape_string($conn, $_POST['description']);
        $building_id = $_POST['building_id'];
        $category_id = $_POST['category_id'];
        $priority = $_POST['priority'];
        $is_weekly = isset($_POST['is_weekly']) ? 1 : 0;
        $bi_weekly = isset($_POST['bi_weekly']) ? 1 : 0;
        $is_public = isset($_POST['is_public']) ? 1 : 0;
        $coordinator = mysqli_real_escape_string($conn, $_POST['coordinator']);
        $address = mysqli_real_escape_string($conn, $_POST['address']);
        $postcode = mysqli_real_escape_string($conn, $_POST['postcode']);
        $capacity = $_POST['capacity'];
        $email = $_POST['email'];
        $required_booking = isset($_POST['required_booking']) ? 1 : 0;

        // Check if a new image is uploaded
        if (!empty($_FILES['image']['name'])) {

            $image = $_FILES['image']['name'];
            $targetDirectory = "eventImages/";
            $image = $_FILES['image']['name'];
            $targetPath = $targetDirectory . basename($image);
            move_uploaded_file($_FILES["image"]["tmp_name"], $targetPath);


            $sql = "UPDATE events SET title = '$title', image = '$targetPath', start_date = '$start_date', start_time = '$start_time', end_date = '$end_date', end_time = '$end_time', description = '$description', building_id = '$building_id', category_id = '$category_id', priority = '$priority', is_weekly = '$is_weekly', bi_weekly = '$bi_weekly', is_public = '$is_public', coordinator = '$coordinator', address = '$address', postcode = '$postcode', capacity = '$capacity', email = '$email', required_booking = '$required_booking' WHERE id = $event_id";
        } else {
            $sql = "UPDATE events SET title = '$title', start_date = '$start_date', start_time = '$start_time', end_date = '$end_date', end_time = '$end_time', description = '$description', building_id = '$building_id', category_id = '$category_id', priority = '$priority', is_weekly = '$is_weekly', bi_weekly = '$bi_weekly', is_public = '$is_public', coordinator = '$coordinator', address = '$address', postcode = '$postcode', capacity = '$capacity', email = '$email', required_booking = '$required_booking' WHERE id = $event_id";
        }

        if ($conn->query($sql) === TRUE) {
            header("Location: events.php?success=Event updated successfully");
            exit();
        } else {

            $error = "Error: " . $sql . "<br>" . $conn->error;
            header("Location: events.php?error=" . urlencode($error));
            exit();
        }
    } else {

        header("Location: events.php");
    }
}




$conn->close();
