<!-- Sidebar Start -->
<?php
include('layout.php');
include('includes/db.php')
?>
<!--  Sidebar End -->

<!-- Sidebar Start -->
<?php
include('includes/sidebar.php')
?>
<!--  Sidebar End -->


<div class="body-wrapper">
    <!--  Header Start -->
    <?php
    include('includes/header.php')
    ?>
    <!--  Header End -->
    <div class="container-fluid">

        <div class="row">
            <div class="col-lg-3 d-flex align-items-stretch">
                <div class="card w-100">
                    <div class="card-body p-4 ">
                        <div class="d-flex gap-2">
                            <i class="ti ti-article"></i>

                            <h6>Events</h6>
                        </div>
                        <h6 class="px-3">10</h6>

                    </div>
                </div>
            </div>
            <div class="col-lg-3 d-flex align-items-stretch">
                <div class="card w-100">
                    <div class="card-body p-4 ">
                        <div class="d-flex gap-2">

                            <i class="ti ti-article"></i>

                            <h6>Total Categories</h6>
                        </div>
                        <?php
                        $sql = "SELECT COUNT(*) AS totalcategories FROM categories";
                        $result = $conn->query($sql);

                        if ($result->num_rows > 0) {
                            $row = $result->fetch_assoc();
                            $totalcategories = $row['totalcategories'];
                        ?>
                            <h6 class="px-3"><?php echo $totalcategories ?></h6>
                        <?php
                        } else {
                        ?>

                            <h6 class="px-3">0</h6>
                        <?php
                        }
                        ?>




                    </div>
                </div>
            </div>

            <div class="col-lg-3 d-flex align-items-stretch">
                <div class="card w-100">
                    <div class="card-body p-4 ">
                        <div class="d-flex gap-2">
                            <i class="ti ti-article"></i>
                            <h6>Rooms</h6>
                        </div>

                        <?php
                        $sql = "SELECT COUNT(*) AS total_buildings FROM buildings";
                        $result = $conn->query($sql);

                        if ($result->num_rows > 0) {
                            $row = $result->fetch_assoc();
                            $total_buildings = $row['total_buildings'];
                        ?>
                            <h6 class="px-3"><?php echo $total_buildings ?></h6>
                        <?php
                        } else {
                        ?>

                            <h6 class="px-3">0</h6>
                        <?php
                        }
                        ?>

                    </div>
                </div>
            </div>

            <div class="col-lg-3 d-flex align-items-stretch">
                <div class="card w-100">
                    <div class="card-body p-4 ">
                        <div class="d-flex gap-2">
                            <i class="ti ti-users"></i>
                            <h6>Users</h6>
                        </div>


                        <?php
                        $sql = "SELECT COUNT(*) AS total_users FROM users";
                        $result = $conn->query($sql);

                        if ($result->num_rows > 0) {
                            $row = $result->fetch_assoc();
                            $total_users = $row['total_users'];
                        ?>
                            <h6 class="px-3"><?php echo $total_users ?></h6>
                        <?php
                        } else {
                        ?>

                            <h6 class="px-3">0</h6>
                        <?php
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <h2 class="fw-bold mb-3">Events</h2>
            <?php
            $sql = "SELECT events.*, buildings.name AS building_name
            FROM events
            LEFT JOIN buildings ON events.building_id = buildings.id
            LIMIT 4";
            $result = $conn->query($sql);



            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {


            ?>

                    <div class="col-sm-6 col-xl-3">
                        <div class="card overflow-hidden rounded-2" style="height: 300px;">
                            <div class="position-relative" style="height: 300px;">
                                <a href="javascript:void(0)"><img src="<?php echo $row['image'] ?>" class="card-img-top rounded-0" style="height: 200px;" alt="..."></a>
                            </div>
                            <div class="card-body pt-3 p-4">
                                <h6 class="fw-semibold fs-4">
                                    <?php echo strlen($row['title']) > 20 ? substr($row['title'], 0, 20) . '...' : $row['title']; ?>
                                </h6>
                                <div class="d-flex align-items-center justify-content-between">
                                    <h6 class="fw-semibold fs-4 mb-0"><?php echo $row['start_date'] ?> <span class="ms-2 fw-normal text-muted fs-3"></span></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php

                    ?>

            <?php }
            } ?>


        </div>
















        <?php include('includes/sign.php') ?>
    </div>
</div>
</div>

<?php
include('includes/footer.php')
?>