<!-- Sidebar Start -->
<?php
include('layout.php');
include('includes/db.php')
?>
<!--  Sidebar End -->

<!-- Sidebar Start -->
<?php
include('includes/sidebar.php')
?>
<!--  Sidebar End -->


<div class="body-wrapper">
    <!--  Header Start -->
    <?php
    include('includes/header.php')
    ?>
    <!--  Header End -->
    <div class="container-fluid">
        <div class="container-fluid">
            <div class="card">
                <div class="card-body mb-5">
                    <h5 class="card-title fw-semibold mb-4">Create New Event</h5>
                    <div class=" mb-5">

                        <?php

                        if (isset($_GET['id'])) {
                            $categoryId = $_GET['id'];

                            $sql = "SELECT * FROM events WHERE id=" . $categoryId;
                            $result = $conn->query($sql);

                            if ($result->num_rows > 0) {
                                $event = $result->fetch_assoc();
                            }
                        }
                        ?>

                        <div class="">
                            <form method="POST" enctype="multipart/form-data" action="edit-event-process.php">
                                <div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label">Event Title</label>

                                    <input type="hidden" name="type" value="update-event">

                                    <input type="hidden" name="event_id" value="<?php echo $event['id'] ?>">


                                    <input type="text" value="<?php echo $event['title'] ?>" name="title" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" required>
                                </div>


                                <div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label">Start Date</label>

                                    <input type="date" name="start_date" value="<?php echo $event['start_date'] ?>" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" required>
                                </div>


                                <div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label">Start Time</label>

                                    <input type="time" name="start_time" value="<?php echo $event['start_time'] ?>" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" required>
                                </div>


                                <div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label">End Date</label>

                                    <input type="date" name="end_date" value="<?php echo $event['end_date'] ?>" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" required>
                                </div>


                                <div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label">End Time</label>

                                    <input type="time" name="end_time" value="<?php echo $event['end_time'] ?>" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" required>
                                </div>





                                <div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label">Description</label>
                                    <textarea name="description" class="form-control" id="" cols="30" rows="4"><?php echo $event['description'] ?></textarea>
                                </div>


                                <div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label">Image</label>
                                    <input type="file" name="image" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                                </div>

                                <div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label">Room</label>

                                    <select name="building_id" class="form-control" id="">

                                        <?php
                                        $sql = "SELECT * FROM buildings";
                                        $result = $conn->query($sql);


                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {

                                        ?>
                                                <option value="<?php echo $row['id']; ?>" <?php if ($row['id'] == $event['building_id']) {
                                                                                                echo 'selected';
                                                                                            } ?>>
                                                    <?php echo $row['name']; ?>
                                                </option>
                                        <?php
                                            }
                                        }
                                        ?>


                                    </select>
                                </div>

                                <div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label">Category</label>
                                    <select name="category_id" class="form-control" id="">
                                        <?php
                                        $sql = "SELECT * FROM categories";
                                        $result = $conn->query($sql);


                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {
                                        ?>
                                                <option value="<?php echo $row['id']; ?>" <?php if ($row['id'] == $event['category_id']) {
                                                                                                echo 'selected';
                                                                                            } ?>>
                                                    <?php echo $row['name']; ?>
                                                </option>
                                        <?php
                                            }
                                        }
                                        ?>

                                    </select>

                                </div>

                                <div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label">Priority</label>
                                    <select name="priority" class="form-control" id="">
                                        <option value="Low" <?php echo ($event['priority'] == 'Low') ? 'selected' : ''; ?>>Low</option>
                                        <option value="High" <?php echo ($event['priority'] == 'High') ? 'selected' : ''; ?>>High</option>
                                        <option value="Medium" <?php echo ($event['priority'] == 'Medium') ? 'selected' : ''; ?>>Medium</option>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <input type="checkbox" name="is_weekly" value="1" class="" id="exampleInputEmail1" aria-describedby="emailHelp" <?php echo $event['is_weekly'] ? 'checked' : ''; ?>>
                                    <label for="exampleInputEmail1" class="form-label">Is Weekly</label>
                                </div>

                                <div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label">
                                        <input type="checkbox" name="bi_weekly" value="1" class="" id="exampleInputEmail1" aria-describedby="emailHelp" <?php echo $event['bi_weekly'] ? 'checked' : ''; ?>> Bi Weekly
                                    </label>
                                </div>

                                <div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label">
                                        <input type="checkbox" name="is_public" value="1" class="" id="exampleInputEmail1" aria-describedby="emailHelp" <?php echo $event['is_public'] ? 'checked' : ''; ?>> Is Public
                                    </label>
                                </div>


                                <div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label">Coordinator</label>

                                    <input type="text" name="coordinator" value="<?php echo $event['coordinator'] ?>" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" required>
                                </div>

                                <div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label">Address</label>

                                    <input type="text" name="address" value="<?php echo $event['address'] ?>" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" required>
                                </div>

                                <div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label">Postcode</label>

                                    <input type="text" name="postcode" value="<?php echo $event['postcode'] ?>" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" required>
                                </div>


                                <div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label">Capacity</label>

                                    <input type="number" name="capacity" value="<?php echo $event['capacity'] ?>" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" required>
                                </div>


                                <div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label">Email</label>

                                    <input type="email" name="email" value="<?php echo $event['email'] ?>" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" required>
                                </div>

                                <div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label"> <input type="checkbox" <?php echo $event['required_booking'] ? 'checked' : ''; ?> name="required_booking" value="required_booking" class="" id="exampleInputEmail1" aria-describedby="emailHelp" required> Required Booking</label>
                                </div>

                                <button type="submit" class="btn btn-primary" style="width: 20%;">Add Event</button>
                            </form>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <?php include('includes/sign.php') ?>
    </div>
</div>
</div>

<?php
include('includes/footer.php')
?>