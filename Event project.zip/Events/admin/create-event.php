<!-- Sidebar Start -->
<?php
include('layout.php');
include('includes/db.php')
?>
<!--  Sidebar End -->

<!-- Sidebar Start -->
<?php
include('includes/sidebar.php')
?>
<!--  Sidebar End -->


<div class="body-wrapper">
    <!--  Header Start -->
    <?php
    include('includes/header.php')
    ?>
    <!--  Header End -->
    <div class="container-fluid">
        <div class="container-fluid">
            <div class="card">
                <div class="card-body mb-5">
                    <h5 class="card-title fw-semibold mb-4">Create New Event</h5>
                    <div class=" mb-5">
                        <div class="">
                            <form method="POST" enctype="multipart/form-data" action="admin-database-process.php">
                                <div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label">Event Title</label>
                                    <input type="hidden" name="form_type" value="create-event">

                                    <input type="text" name="title" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" required>
                                </div>


                                <div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label">Start Date</label>

                                    <input type="date" name="start_date" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" required>
                                </div>


                                <div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label">Start Time</label>

                                    <input type="time" name="start_time" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" required>
                                </div>


                                <div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label">End Date</label>

                                    <input type="date" name="end_date" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" required>
                                </div>


                                <div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label">End Time</label>

                                    <input type="time" name="end_time" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" required>
                                </div>





                                <div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label">Description</label>
                                    <textarea name="description" required class="form-control" id="" cols="30" rows="4"></textarea>
                                </div>


                                <div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label">Image</label>
                                    <input type="file" name="image" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" required>
                                </div>

                                <div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label">Room</label>

                                    <select name="building_id" required class="form-control" id="">

                                        <?php
                                        $sql = "SELECT * FROM buildings";
                                        $result = $conn->query($sql);


                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {

                                        ?>
                                                <option value="<?php echo $row['id'] ?>"><?php echo $row['name'] ?></option>
                                        <?php
                                            }
                                        }
                                        ?>


                                    </select>
                                </div>

                                <div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label">Category</label>
                                    <select name="category_id" required class="form-control" id="">
                                        <?php
                                        $sql = "SELECT * FROM categories";
                                        $result = $conn->query($sql);


                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {

                                        ?>
                                                <option value="<?php echo $row['id'] ?>"><?php echo $row['name'] ?></option>
                                        <?php
                                            }
                                        }
                                        ?>

                                    </select>

                                </div>

                                <div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label">Priority</label>
                                    <select name="priority" required class="form-control" id="">
                                        <option value="Low">Low</option>
                                        <option value="High">High</option>
                                        <option value="Medium">Medium</option>
                                    </select>

                                </div>
                                <!-- <div class="mb-3">
                                    <input type="checkbox" name="is_weekly" value="is_weekly" class="" id="exampleInputEmail1" aria-describedby="emailHelp">
                                    <label for="exampleInputEmail1" class="form-label">Is Weekly </label>


                                </div>

                                <div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label"> <input type="checkbox" name="bi_weekly" value="bi_weekly" class="" id="exampleInputEmail1" aria-describedby="emailHelp"> Bi Weeokly</label>
                                </div>


                                <div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label"> <input type="checkbox" name="is_public" value="is_public" class="" id="exampleInputEmail1" aria-describedby="emailHelp"> Is Public</label>
                                </div> -->

                                <div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label">Coordinator</label>

                                    <input type="text" name="coordinator" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" required>
                                </div>

                                <div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label">Address</label>

                                    <input type="text" name="address" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" required>
                                </div>

                                <div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label">Postcode</label>

                                    <input type="text" name="postcode" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" required>
                                </div>


                                <div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label">Capacity</label>

                                    <input type="number" name="capacity" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" required>
                                </div>


                                <div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label">Email</label>

                                    <input type="email" name="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" required>
                                </div>

                                <div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label"> <input type="checkbox" name="required_booking" value="required_booking" class="" id="exampleInputEmail1" aria-describedby="emailHelp" required> Required Booking</label>
                                </div>

                                <button type="submit" class="btn btn-primary" style="width: 20%;">Add Event</button>
                            </form>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <?php include('includes/sign.php') ?>
    </div>
</div>
</div>

<?php
include('includes/footer.php')
?>