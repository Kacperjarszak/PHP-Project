<!-- Sidebar Start -->
<?php
include('layout.php')
?>
<!--  Sidebar End -->

<!-- Sidebar Start -->
<?php
include('includes/sidebar.php')
?>
<!--  Sidebar End -->


<div class="body-wrapper">
    <!--  Header Start -->
    <?php
    include('includes/header.php')
    ?>
    <!--  Header End -->
    <div class="container-fluid">
        <div class="container-fluid">
            <div class="card">
                <div class="card-body mb-5">
                    <h5 class="card-title fw-semibold mb-4">Add Category</h5>
                    <div class=" mb-5">
                        <div class="">
                            <form method="POST" action="admin-database-process.php">
                                <div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label">Category Name</label>
                                    <input type="hidden" name="form_type" value="create-category">

                                    <input type="text" name="name" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                                </div>
                                <button type="submit" class="btn btn-primary" style="width: 20%;">Add </button>
                            </form>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <?php include('includes/sign.php') ?>
    </div>
</div>
</div>

<?php
include('includes/footer.php')
?>