<?php
include('includes/db.php');

session_start(); // Start the session



include('includes/db.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['type']) && $_POST['type'] == 'update-event') {

        $event_id = $_POST['event_id'];
        $title = mysqli_real_escape_string($conn, $_POST['title']);
        $start_date = $_POST['start_date'];
        $start_time = $_POST['start_time'];
        $end_date = $_POST['end_date'];
        $end_time = $_POST['end_time'];
        $description = mysqli_real_escape_string($conn, $_POST['description']);
        $building_id = $_POST['building_id'];
        $category_id = $_POST['category_id'];
        $priority = $_POST['priority'];
        $is_weekly = isset($_POST['is_weekly']) ? 1 : 0;
        $bi_weekly = isset($_POST['bi_weekly']) ? 1 : 0;
        $is_public = isset($_POST['is_public']) ? 1 : 0;
        $coordinator = mysqli_real_escape_string($conn, $_POST['coordinator']);
        $address = mysqli_real_escape_string($conn, $_POST['address']);
        $postcode = mysqli_real_escape_string($conn, $_POST['postcode']);
        $capacity = $_POST['capacity'];
        $email = $_POST['email'];
        $required_booking = isset($_POST['required_booking']) ? 1 : 0;

        // Check if a new image is uploaded
        if (!empty($_FILES['image']['name'])) {

            $image = $_FILES['image']['name'];
            $targetDirectory = "eventImages/";
            $image = $_FILES['image']['name'];
            $targetPath = $targetDirectory . basename($image);
            move_uploaded_file($_FILES["image"]["tmp_name"], $targetPath);


            $sql = "UPDATE events SET title = '$title', image = '$targetPath', start_date = '$start_date', start_time = '$start_time', end_date = '$end_date', end_time = '$end_time', description = '$description', building_id = '$building_id', category_id = '$category_id', priority = '$priority', is_weekly = '$is_weekly', bi_weekly = '$bi_weekly', is_public = '$is_public', coordinator = '$coordinator', address = '$address', postcode = '$postcode', capacity = '$capacity', email = '$email', required_booking = '$required_booking' WHERE id = $event_id";
        } else {
            $sql = "UPDATE events SET title = '$title', start_date = '$start_date', start_time = '$start_time', end_date = '$end_date', end_time = '$end_time', description = '$description', building_id = '$building_id', category_id = '$category_id', priority = '$priority', is_weekly = '$is_weekly', bi_weekly = '$bi_weekly', is_public = '$is_public', coordinator = '$coordinator', address = '$address', postcode = '$postcode', capacity = '$capacity', email = '$email', required_booking = '$required_booking' WHERE id = $event_id";
        }

        if ($conn->query($sql) === TRUE) {
            header("Location: events.php?success=Event updated successfully");
            exit();
        } else {

            $error = "Error: " . $sql . "<br>" . $conn->error;
            header("Location: events.php?error=" . urlencode($error));
            exit();
        }
    } else {

        header("Location: events.php");
    }
}




$conn->close();
