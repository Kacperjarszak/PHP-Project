<!-- Sidebar Start -->

<?php

include('includes/db.php');

if (isset($_GET['id'])) {
    $categoryId = $_GET['id'];

    $sql = "DELETE FROM users WHERE id=$categoryId";
    if ($conn->query($sql) === TRUE) {
        header("Location: users.php?success=User deleted successfully");
        exit();
    } else {
        $error = "Error: " . $sql . "<br>" . $conn->error;
        header("Location: users.php?error=" . urlencode($error));
        exit();
    }
}


?>