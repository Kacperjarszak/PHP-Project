<!-- Sidebar Start -->

<?php

include('includes/db.php');

if (isset($_GET['id'])) {
    $categoryId = $_GET['id'];

    $sql = "DELETE FROM categories WHERE id=$categoryId";
    if ($conn->query($sql) === TRUE) {
        header("Location: event-categories.php?success=Category deleted successfully");
        exit();
    } else {
        $error = "Error: " . $sql . "<br>" . $conn->error;
        header("Location: event-categories.php?error=" . urlencode($error));
        exit();
    }
}


?>