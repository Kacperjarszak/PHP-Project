<?php
include('admin/includes/db.php');

session_start(); // Start the session


if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['form_type']) && $_POST['form_type'] == 'registrationForm') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);

    // Check if the username or email already exists
    $checkQuery = "SELECT * FROM users WHERE username = '$username' OR email = '$email'";
    $result = $conn->query($checkQuery);

    if ($result->num_rows > 0) {
        // Duplicate entry error
        $message = "Error: Username or email already exists.";
        header("Location: register.php?error=" . urlencode($message));
        exit();
    }

    // Insert the new user if not a duplicate
    $insertQuery = "INSERT INTO users (name, email, username, password) VALUES ('$name', '$email', '$username', '$password')";

    if ($conn->query($insertQuery) === TRUE) {
        // Redirect to a success page or home page
        $message = "Success: Register Successfully .";
        header("Location: register.php?success=" . urlencode($message));
        exit();
    } else {
        // Other database error
        $message = "Error: " . $insertQuery . "<br>" . $conn->error;
        header("Location: register.php?error=" . urlencode($message));
        exit();
    }
}




if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['form_type']) && $_POST['form_type'] == 'login') {
    $identifier = $_POST['username']; // Assuming the form field is named 'username'
    $password = $_POST['password'];

    // Perform validation (you should add more secure validation)
    $user = findUser($identifier);

    if ($user && password_verify($password, $user['password'])) {

        $_SESSION['user'] = $user;

        if ($user['role'] == 'user') {
            header("Location: index.php");
        } elseif ($user['role'] == 'admin') {
            header("Location: admin/index.php");
        } else {
            // Handle other roles as needed
            header("Location: login.php");
        }
        exit();
    } else {
        // Authentication failed
        $error = "Invalid username or password";
        header("Location: login.php?error=" . urlencode($error));
        exit();
    }
}



if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['form_type']) && $_POST['form_type'] == 'create-event') {

    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $start_date = $_POST['start_date'];
    $start_time = $_POST['start_time'];
    $end_date = $_POST['end_date'];
    $end_time = $_POST['end_time'];
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $building_id = $_POST['building_id'];
    $category_id = $_POST['category_id'];
    $priority = $_POST['priority'];
    $is_weekly = isset($_POST['is_weekly']) ? 1 : 0;
    $bi_weekly = isset($_POST['bi_weekly']) ? 1 : 0;
    $is_public = isset($_POST['is_public']) ? 1 : 0;
    $coordinator = mysqli_real_escape_string($conn, $_POST['coordinator']);
    $address = mysqli_real_escape_string($conn, $_POST['address']);
    $postcode = mysqli_real_escape_string($conn, $_POST['postcode']);
    $capacity = $_POST['capacity'];
    $email = $_POST['email'];
    $required_booking = isset($_POST['required_booking']) ? 1 : 0;

    $user_id = $_SESSION['user']['id'];


    $targetDirectory = "admin/eventImages/";
    $image = $_FILES['image']['name'];
    $targetPath = $targetDirectory . basename($image);
    move_uploaded_file($_FILES["image"]["tmp_name"], $targetPath);

    // Insert data into the database
    $sql = "INSERT INTO events (created_by,title, start_date, start_time, end_date, end_time, description, image, building_id, category_id, priority, is_weekly, bi_weekly, is_public, coordinator, address, postcode, capacity, email, required_booking) 
        VALUES ('$user_id','$title', '$start_date', '$start_time', '$end_date', '$end_time', '$description', '$targetPath', '$building_id', '$category_id', '$priority', '$is_weekly', '$bi_weekly', '$is_public', '$coordinator', '$address', '$postcode', '$capacity', '$email', '$required_booking')";

    if ($conn->query($sql) === TRUE) {
        header("Location: index.php?success=Event added successfully");
        exit();
    } else {
        $error = "Error: " . $sql . "<br>" . $conn->error;
        header("Location: create-event.php?error=" . urlencode($error));
        exit();
    }
} else {

    header("Location: index.php");
    exit();
}



function findUser($identifier)
{

    include('admin/includes/db.php');

    // Use prepared statements to prevent SQL injection
    $stmt = $conn->prepare("SELECT * FROM users WHERE username = ? OR email = ?");
    $stmt->bind_param("ss", $identifier, $identifier);
    $stmt->execute();

    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        $stmt->close();
        $conn->close();
        return $user;
    }

    $stmt->close();
    $conn->close();
    return null;
}
$conn->close();
