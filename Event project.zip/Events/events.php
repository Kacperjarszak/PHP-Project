<?php
session_start(); // Start the session

// Check if the user is logged in
$isLoggedIn = isset($_SESSION['user']);

include('admin/includes/db.php')

?>

<?php

// $events = [
//     ['title' => 'All Day Event All Day Event ', 'start' => '2023-01-01'],
//     ['title' => 'Long Event', 'start' => '2023-01-07', 'end' => '2023-01-10'],
//     // Add more events as needed
// ];


$events = [];
$sql = "SELECT events.*, buildings.name AS building_name
FROM events
LEFT JOIN buildings ON events.building_id = buildings.id   LIMIT 3";
$result = $conn->query($sql);


if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {

        $color = ($_SESSION['user']['id'] == $row['created_by']) ? 'green' : '';


        $events[] = [
            'title' => $row['title'],
            'start' => $row['start_date'],
            'end' => $row['end_date'],
            'color' => $color,
        ];
    }
}


$eventsJSON = json_encode($events);

?>


<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Admin</title>

    <script src='./dist/index.global.js'></script>
    <script src='./dist/index.global.min.js'></script>

    <link rel="stylesheet" href="admin/assets/css/styles.min.css" />
    <style>
        #calendar-container {
            max-width: 100%;
            overflow: auto;
        }

        .fc-daygrid-event {
            white-space: normal !important;
            align-items: normal !important;
        }

        .fc-daygrid-event {
            display: block !important;
            padding-left: 15px !important;
        }

        .fc-daygrid-event {
            white-space: normal !important;
            align-items: normal !important;
        }

        .fc-daygrid-event-dot {
            display: inline-flex;
            position: absolute;
            left: 0px;
            top: 6px;
        }

        .fc-event-time,
        .fc-event-title {
            display: inline;
        }
    </style>
</head>

<body>

    <div class="overlay"></div>
    <!-- navbar start -->
    <?php
    include('navbar.php')
    ?>


    <div class="div" style="height: 350px;">
        <img src="images/eventBanner.jpg" alt="" style="width: 100%; height:350px">
    </div>

    <div class="container">
        <div class="row d-flex justify-content-center">
            <div class="col-lg-10">
                <div class="row d-flex justify-content-center mt-5">
                    <div class="col-lg-7 ">
                        <a href="index.php" class="btn btn-outline-info" style="width: 180px;">View List</a>
                        <a href="create-event.php" class="btn btn-outline-info" style="width: 180px;"><i class="ti ti-edit"></i> Create Event</a>
                        <a href="" class="btn btn-outline-info" style="width: 180px;">Join EVent</a>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="container mt-4">
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                var calendarEl = document.getElementById('calendar');

                // Get current year and month
                var currentDate = new Date();
                var currentYear = currentDate.getFullYear();
                var currentMonth = currentDate.getMonth() + 1;

                var formattedMonth = currentMonth < 10 ? '0' + currentMonth : currentMonth;

                var initialDate = currentYear + '-' + formattedMonth + '-01';

                var calendar = new FullCalendar.Calendar(calendarEl, {
                    headerToolbar: {
                        left: 'prevYear,prev,next,nextYear today',
                        center: 'title',
                        right: 'dayGridMonth,dayGridWeek,dayGridDay'
                    },
                    initialDate: initialDate,
                    navLinks: true,
                    editable: true,
                    dayMaxEvents: true,
                    events: <?php echo $eventsJSON; ?>,
                    eventRender: function(info) {
                        var title = info.event.title;

                        var truncatedTitle = title.length > 20 ? title.substring(0, 20) + '...' : title;

                        var titleHTML = truncatedTitle.replace(/\n/g, '<br>');

                        info.el.querySelector('.fc-title').innerHTML = titleHTML;
                    }
                });

                calendar.render();
            });
        </script>

        <div id='calendar-container'>
            <div id='calendar'></div>
        </div>

    </div>



    <!-- navbar end -->
    <script src=" assets/libs/jquery/dist/jquery.min.js">
    </script>
    <script src="assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>