<?php
session_start(); // Start the session

// Check if the user is logged in

$isLoggedIn = isset($_SESSION['user']);

include('admin/includes/db.php')

?>

<?php
// Sample array of events



$events = [];
$sql = "SELECT events.*, buildings.name AS building_name
FROM events
LEFT JOIN buildings ON events.building_id = buildings.id   LIMIT 3";
$result = $conn->query($sql);


if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        // Create an array for each event and add it to the $events array

        $events[] = [
            'name' => 'Event ' . $row['id'],        // Change 'title' to the actual column name
            'date' => $row['start_date'] . ' ' . $row['start_time'], // Assuming 'start_date' and 'start_time' are columns
            'building_name' => $row['building_name'],
            // Add more fields as needed
        ];
    }
}

?>

<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Admin</title>

    <link rel="stylesheet" href="admin/assets/css/styles.min.css" />

    <style>
        body {
            margin: 0;
            padding: 0;
            height: 100vh;
            background-image: url('images/bgHomeImage.jpg');
            background-size: cover;
            background-repeat: no-repeat;
            color: #fff;
            /* Set text color to contrast with the background */
            font-family: Arial, sans-serif;
        }

        /* Apply opacity to the background image */
        body::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            /* Adjust the alpha value for transparency */
            z-index: -1;
            /* Place it behind the content */
        }
    </style>
</head>

<body>

    <div class="overlay"></div>
    <!-- navbar start -->
    <?php
    include('navbar.php')
    ?>



    <?php

    if ($isLoggedIn) {


    ?>

        <div class="container h-100 d-flex justify-content-center align-items-center">
            <div>
                <p class="text-center text-white">
                    <?php foreach ($events as $index => $event) : ?>
                <h3 style="background-color:rgba(0, 0, 0, 0.5); color:#fff; padding:30px; border-radius:10px" id="demo<?php echo $index; ?>"></h3>
            <?php endforeach; ?>
            </p>
            </div>
        </div>
    <?php


    } ?>


    <script>
        // Sample array of events in JavaScript
        var events = <?php echo json_encode($events); ?>;

        function updateCountdowns() {
            // Get the current time
            var now = new Date().getTime();

            // Loop through each event
            events.forEach(function(event, index) {
                // Calculate the time difference
                var distance = new Date(event.date).getTime() - now;

                // Calculate days, hours, minutes, and seconds
                var days = Math.floor(distance / (1000 * 60 * 60 * 24));
                var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
                var seconds = Math.floor((distance % (1000 * 60)) / 1000);

                // Display the countdown in the corresponding element
                document.getElementById("demo" + index).innerHTML = '<p class="text-white; " style="font-size:14px;margin-left:24px">NEXT</p><h2 style="color:red; font-weight:bold; margin-top:-22px">' + event.name + '</h2>' + ' ' + days + ' days ' + hours + 'hrs ' + minutes + 'mins ' + seconds + 'sec';
                document.getElementById("demo" + index).innerHTML = '<table style="width:400px"> <tr><td> <span style="margin-left:15px;font-size:14px;">NEXT</span> <br /><span style="color:red; font-weight:bold; font-size:27px">' + event.name + '</span> </td><td>' + days + '</td> <td>' + hours + '</td> <td>' + minutes + '</td> <td>' + seconds + '</td></tr>   </td></tr> <tr> <td></td> <td style="color:#a8a8a8">DAYS</td> <td style="color:#a8a8a8">HRS</td> <td style="color:#a8a8a8">MINS</td> <td style="color:#a8a8a8">SEC</td></tr></table>';
            });
        }

        // Update countdowns every second
        setInterval(updateCountdowns, 1000);

        // Initial call to set initial values
        updateCountdowns();
    </script>

    <!-- navbar end -->
    <script src=" assets/libs/jquery/dist/jquery.min.js">
    </script>
    <script src="assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>